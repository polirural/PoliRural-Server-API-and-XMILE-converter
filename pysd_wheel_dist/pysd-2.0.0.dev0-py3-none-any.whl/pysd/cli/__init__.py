"""
Command line parsing and executing scripts
"""
from .main import main
